
# PARECER TÉCNICO – RIGIDEZ DO BLUEPRINT

## Sumário Geral

**Pontuação de Rigidez:** 89/100  
O pacote apresenta um alto nível de amadurecimento técnico, com contratos explícitos, export determinístico com regras de bloqueio claras, validações bem definidas, política de versões robusta, plano de testes abrangente e checklists operacionais.  
Entretanto, ainda há lacunas pontuais que precisam ser endereçadas para garantir previsibilidade absoluta: critérios de aceite formalizados em BDD, mapeamento WCAG 2.2 AA por componente, e um plano de telemetria mais prescritivo.

---

## Pontos Fortes

### ✅ Export determinístico com gating
- Regra única de bloqueio baseada em `errors.length > 0`.
- Lista clara de códigos que bloqueiam `index.html` e `site.zip`.

### ✅ Pipeline do Parser
- Determinístico e minimalista.
- Uso de Tailwind via CDN, tokens em `<style>`, Alpine incluído apenas com efeitos (`fx`).

### ✅ Contrato de Schema
- Campos obrigatórios, regras de IDs.
- Estrutura clara de nós e props por breakpoint.

### ✅ Validações (E/W)
- Biblioteca documentada com semântica, quick-fix e payload esperado via `validation.json`.

### ✅ Acessibilidade nos FX
- Suporte a teclas de navegação e `prefers-reduced-motion`.

### ✅ Plano de Testes
- Matriz por camada: unit, snapshot, integration, E2E, A11y, Perf.
- Browsers alvo definidos.

### ✅ Telemetria mínima
- Ações básicas cobertas: abrir Drawer, aplicar fix, export.

### ✅ Governança de versões
- Version Matrix, processo de release (RC, freeze, artifacts, migração).

### ✅ Checklists de execução
- Aplicados em Onboarding e Macro Strategy, reduzindo ambiguidade.

---

## Lacunas Identificadas e Ações Recomendadas

### 1. Acessibilidade formalizada (WCAG 2.2 AA)
**Problema:** Práticas existem, mas não há mapeamento formal por componente/efeito.  
**Ação:** Criar tabela “Critério → Evidência → Teste” conectada ao Testing Plan (axe + e2e).

---

### 2. Critérios de aceite em BDD
**Problema:** Falta formalização de critérios em formato Gherkin.  
**Ação:** Criar `.feature` curtos para:
- Export bloqueia com E*.
- Fix remove item e revalida.
- Hero split sem media dispara E085.

Amarrar aos testes de integração (Parser/Drawer).

---

### 3. Métricas e analytics do produto
**Problema:** Telemetria mínima ok, mas sem dicionário formal de eventos.  
**Ação:** Publicar `tracking-plan.md` com:
- Nome dos eventos.
- Schema e payloads (sem PII).
- Owner.
- Meta de qualidade de dados.

Eventos iniciais: `ui_open`, `fix_applied`, `export_blocked`, `export_done`.

---

### 4. Performance budgets explícitos
**Problema:** UI é otimizada, mas export não tem metas formais.  
**Ação:** Adicionar metas mínimas no Export Presets:
- LCP ≤ 2.5s P75
- TTI ≤ 3.8s
- CLS ≤ 0.1

Incluir smoke de Lighthouse no Testing Plan.

---

### 5. Segurança e privacidade
**Problema:** Plugin API está segura, mas falta documentação pública.  
**Ação:** Criar `Security Notes` com:
- CSP recomendada para `index.html`.
- Política de assets no `site.zip`.
- Revisão de permissões dos plugins.

---

### 6. SEO e metadados no export
**Problema:** `index.html` funcional, mas incompleto para SEO.  
**Ação:** Expandir presets com:
- title, description, og/twitter tags, favicon, robots.txt.

---

### 7. Personas e JTBD
**Problema:** ICP e KPIs definidos, mas faltam cenas de uso operacionais.  
**Ação:** Criar 2–3 JTBD com:
- Fricções.
- Tarefas.
- Definition of Done por fluxo (montagem, validação, export).

---

### 8. Governança de mudança de contrato
**Problema:** Falta de RACI explícito para mudanças em Schema, Parser, Códigos E/W.  
**Ação:** Publicar tabela RACI + checklist de cross-docs:
- Validation Codes
- Drawer microcopy
- Testing Plan
- Templates
- Onboarding

---

## Pontuação por Dimensão

| Dimensão                             | Nota /10 |
|--------------------------------------|----------|
| Escopo dos artefatos e limites       | 9        |
| Objetivos & KPIs                     | 8        |
| Personas & cenários de uso (JTBD)    | 6        |
| Fluxos & Interface de Autor          | 8        |
| Requisitos funcionais testáveis      | 9        |
| Não-funcionais (perf, a11y, etc.)    | 8        |
| Critérios de aceite (BDD)            | 4        |
| Dependências & riscos                | 8        |
| Métricas & tracking plan             | 7        |
| Governança & versões                 | 9        |

---

## Endurecimentos Recomendados (Aplicáveis Imediatamente)

- ✅ A11y Matrix por componente, com critérios, evidências e testes automatizados (axe + e2e).
- ✅ `.feature` files com BDD para cenários críticos.
- ✅ Performance budgets no Export Presets + smoke de Lighthouse.
- ✅ Tracking plan com schema e owner dos eventos.
- ✅ Notas de segurança com CSP e política de plugins/assets.
- ✅ SEO mínimo no `index.html`.
- ✅ RACI para mudanças de contrato e dependências cruzadas.
- ✅ Seeds com 2 personas e JTBD claros.
- ✅ Tabela de compatibilidade do Parser por layout.version.

---

## Veredito

O blueprint é **sólido e operacionalmente confiável**. Há contratos, validações, planos de teste e governança formal bem estabelecidos.  
Para atingir excelência irrefutável, resta resolver três pendências críticas:

1. WCAG mapeada por componente.  
2. Critérios de aceite formais em BDD.  
3. Tracking plan com dicionário prescritivo.

Com isso, o sistema evolui de “muito bom” para **irritantemente impecável**.

---

**Este documento é referência oficial para próximos passos dentro do ambiente Tello.**
